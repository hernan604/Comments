rm comente.xpi
zip -r comente.xpi *
